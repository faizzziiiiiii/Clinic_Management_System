from rest_framework import viewsets, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from admin_panel.permissions import IsDoctor
from receptionist.models import Appointment, Patient
from .models import Consultation
from .serializers import (
    DoctorAppointmentSerializer,
    ConsultationSerializer,
    DoctorPatientSerializer,
    PatientHistorySerializer,
    ConsultationShortSerializer,  # <-- ADDED
)


# Doctor sees only his appointments
class DoctorAppointmentViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = DoctorAppointmentSerializer
    permission_classes = [permissions.IsAuthenticated, IsDoctor]

    def get_queryset(self):
        return Appointment.objects.filter(
            doctor=self.request.user
        ).order_by("-created_at")


# Doctor creates/updates consultation
class ConsultationViewSet(viewsets.ModelViewSet):
    serializer_class = ConsultationSerializer
    permission_classes = [permissions.IsAuthenticated, IsDoctor]

    def get_queryset(self):
        return Consultation.objects.filter(doctor=self.request.user)

    def create(self, request, *args, **kwargs):
        appointment_id = request.query_params.get("appointment_id")
        if not appointment_id:
            return Response({"detail": "appointment_id required"},
                            status=status.HTTP_400_BAD_REQUEST)

        try:
            appointment = Appointment.objects.get(
                id=appointment_id,
                doctor=request.user
            )
        except Appointment.DoesNotExist:
            return Response({"detail": "Not your appointment"},
                            status=status.HTTP_404_NOT_FOUND)

        if hasattr(appointment, "consultation"):
            return Response({"detail": "Consultation already exists"},
                            status=status.HTTP_400_BAD_REQUEST)

        serializer = self.get_serializer(
            data=request.data,
            context={"request": request, "appointment": appointment}
        )
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


# Doctor sees patients who visited him
class DoctorPatientsViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = DoctorPatientSerializer
    permission_classes = [permissions.IsAuthenticated, IsDoctor]

    def get_queryset(self):
        return Patient.objects.filter(
            appointments__doctor=self.request.user
        ).distinct()


# Doctor sees patient's visit history with him only
class PatientHistoryView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsDoctor]

    def get(self, request, patient_id):
        try:
            patient = Patient.objects.get(id=patient_id)
        except Patient.DoesNotExist:
            return Response({"detail": "Patient not found"},
                            status=status.HTTP_404_NOT_FOUND)

        consultations = Consultation.objects.filter(
            patient=patient,
            doctor=request.user
        ).order_by("-created_at")

        serializer = PatientHistorySerializer(patient).data
        serializer["consultations"] = ConsultationShortSerializer(
            consultations, many=True
        ).data

        return Response(serializer, status=status.HTTP_200_OK)
