from rest_framework import serializers

from admin_panel.models import User
from receptionist.models import Appointment, Patient
from receptionist.serializers import AppointmentSerializer, PatientSerializer

from .models import Consultation, PrescriptionItem


class PrescriptionItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = PrescriptionItem
        fields = [
            "id",
            "medicine_name",
            "dosage",
            "frequency",
            "duration",
            "instructions",
        ]


class ConsultationSerializer(serializers.ModelSerializer):
    # nested prescriptions
    prescriptions = PrescriptionItemSerializer(many=True)

    # some extra read-only info for UI
    patient = PatientSerializer(read_only=True)
    appointment = serializers.PrimaryKeyRelatedField(read_only=True)

    class Meta:
        model = Consultation
        fields = [
            "id",
            "appointment",
            "doctor",
            "patient",
            "clinical_notes",
            "refer_to_lab",
            "prescriptions",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["doctor", "patient", "created_at", "updated_at"]

    def create(self, validated_data):
        """
        Create consultation with nested prescriptions.
        Appointment is passed from the view.
        """
        prescriptions_data = validated_data.pop("prescriptions", [])

        appointment = self.context["appointment"]
        doctor = self.context["request"].user
        patient = appointment.patient

        consultation = Consultation.objects.create(
            appointment=appointment,
            doctor=doctor,
            patient=patient,
            **validated_data,
        )

        for item in prescriptions_data:
            PrescriptionItem.objects.create(
                consultation=consultation, **item
            )

        return consultation

    def update(self, instance, validated_data):
        """
        Update clinical notes / refer_to_lab / prescriptions.
        Simple strategy: delete old prescriptions and recreate.
        """
        prescriptions_data = validated_data.pop("prescriptions", None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if prescriptions_data is not None:
            instance.prescriptions.all().delete()
            for item in prescriptions_data:
                PrescriptionItem.objects.create(
                    consultation=instance, **item
                )

        return instance


class DoctorAppointmentSerializer(serializers.ModelSerializer):
    """
    Lightweight appointment list for doctor portal.
    """
    patient = PatientSerializer(read_only=True)

    class Meta:
        model = Appointment
        fields = [
            "id",
            "token_number",
            "status",
            "created_at",
            "patient",
            "department",
        ]


class DoctorPatientSerializer(serializers.ModelSerializer):
    """
    Distinct patients that this doctor has seen / will see.
    """
    class Meta:
        model = Patient
        fields = [
            "id",
            "patient_id",
            "full_name",
            "age",
            "gender",
            "contact_number",
        ]


# For patient history endpoint
class ConsultationShortSerializer(serializers.ModelSerializer):
    prescriptions = PrescriptionItemSerializer(many=True)

    class Meta:
        model = Consultation
        fields = [
            "id",
            "clinical_notes",
            "refer_to_lab",
            "prescriptions",
            "created_at",
        ]


class PatientHistorySerializer(serializers.ModelSerializer):
    consultations = ConsultationShortSerializer(many=True)

    class Meta:
        model = Patient
        fields = [
            "id",
            "patient_id",
            "full_name",
            "age",
            "gender",
            "consultations",
        ]
