from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from receptionist.permissions import IsReceptionist
from rest_framework.permissions import IsAuthenticated

from .permissions import IsReceptionist
from .models import Patient, Appointment, Bill, Vitals
from .serializers import (
    PatientSerializer,
    AppointmentSerializer,
    BillSerializer,
    DoctorSerializer,
    VitalsSerializer
)
from admin_panel.models import User
from admin_panel.permissions import IsAdmin


# RECEPTIONIST: Manage Patients
class PatientViewSet(viewsets.ModelViewSet):
    queryset = Patient.objects.all().order_by("-created_at")
    serializer_class = PatientSerializer
    permission_classes = [IsReceptionist]


# RECEPTIONIST: Manage Appointments
class AppointmentViewSet(viewsets.ModelViewSet):
    queryset = Appointment.objects.all().order_by("-created_at")
    serializer_class = AppointmentSerializer
    permission_classes = [IsReceptionist]


# RECEPTIONIST: Manage Bills
class BillViewSet(viewsets.ModelViewSet):
    queryset = Bill.objects.all().order_by("-created_at")
    serializer_class = BillSerializer
    permission_classes = [IsReceptionist]


# Receptionist/Admin: Doctors filtered by department
class DoctorsByDepartmentView(APIView):
    permission_classes = [IsReceptionist | IsAdmin]

    def get(self, request, department_id):
        doctors = User.objects.filter(role="DOCTOR", department_id=department_id)
        serializer = DoctorSerializer(doctors, many=True)
        return Response(serializer.data)


class VitalsViewSet(viewsets.ModelViewSet):
    queryset = Vitals.objects.all()
    serializer_class = VitalsSerializer
    permission_classes = [IsAuthenticated, IsReceptionist]

    def perform_create(self, serializer):
        appointment_id = self.request.query_params.get("appointment_id")
        if not appointment_id:
            raise ValueError("appointment_id is required")

        appointment = Appointment.objects.get(id=appointment_id)
        serializer.save(appointment=appointment)