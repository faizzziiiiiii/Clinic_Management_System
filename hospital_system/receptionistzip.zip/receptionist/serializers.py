from rest_framework import serializers
from .models import Patient, Appointment, Bill, Vitals
from admin_panel.models import User


class PatientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Patient
        fields = [
            "id",
            "patient_id",
            "full_name",
            "age",
            "gender",
            "contact_number",
            "blood_group",
            "address",
            "created_at",
        ]
        read_only_fields = ["id", "patient_id", "created_at"]


class AppointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = [
            "id",
            "patient",
            "doctor",
            "department",
            "token_number",
            "status",
            "created_at",
            "vitals",
        ]
        read_only_fields = ["id", "token_number", "status", "created_at"]

    def create(self, validated_data):
        count = Appointment.objects.count() + 1
        token = f"T{count:03d}"
        validated_data["token_number"] = token
        return super().create(validated_data)


from rest_framework import serializers
from .models import Bill

class BillSerializer(serializers.ModelSerializer):
    patient = serializers.CharField(source='appointment.patient.patient_id', read_only=True)
    patient_name = serializers.CharField(source='appointment.patient.full_name', read_only=True)

    class Meta:
        model = Bill
        fields = ["id", "appointment", "patient", "patient_name", "consultation_fee", "created_at"]
        read_only_fields = ["patient", "patient_name", "created_at"]



class DoctorSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "first_name", "last_name"]


class VitalsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vitals
        fields = ["id", "blood_pressure", "pulse", "temperature", "oxygen_saturation", "weight", "created_at"]