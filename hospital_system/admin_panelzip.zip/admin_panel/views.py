from rest_framework import viewsets, permissions
from rest_framework.views import APIView
from rest_framework.response import Response

from rest_framework_simplejwt.views import TokenObtainPairView

from .models import User, Department
from .serializers import (
    EmployeeCreateSerializer,
    EmployeeListSerializer,
    DepartmentSerializer,
    UserBasicSerializer,
    MyTokenObtainPairSerializer,
)
from .permissions import IsAdmin


# JWT login view
class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer


# who am I? (React will call /api/me/ to get role)
class CurrentUserView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        serializer = UserBasicSerializer(request.user)
        return Response(serializer.data)


# ADMIN: employees CRUD
class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = User.objects.exclude(role="ADMIN").order_by("id")
    permission_classes = [IsAdmin]

    def get_serializer_class(self):
        if self.action == "create":
            return EmployeeCreateSerializer
        return EmployeeListSerializer


# ADMIN: departments CRUD
class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all().order_by("name")
    serializer_class = DepartmentSerializer
    permission_classes = [IsAdmin]
